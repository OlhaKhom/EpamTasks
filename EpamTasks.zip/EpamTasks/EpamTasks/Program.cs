﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork1Epam
{
    struct Point
    {
        public int X, Y;
        public Point(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }
        //- method Distance() to calculate distance between points
        //Point A = new Point ( A.X, A.Y);
        //Point D = new Point ( D.X, D.Y);
        //Point B = new Point ( A.X, D.Y);
        //Point C = new Point ( D.X, A.Y);
        public double GetDistance(Point A, Point B)
        {
            return Math.Sqrt(Math.Pow((A.X - B.X), 2) + Math.Pow((A.Y - B.Y), 2));
        }
        //- method ToString(), which return the Point in format "(x,y)"
        public void ToString(Point p)
        {
            Console.WriteLine($"Point {p} ({p.X},{p.Y})");
        }
    }
    class Rectangle
    {
        Point vertex1 { get; }
        Point vertex2 { get; }
        Point vertex3 { get; }
        Point vertex4 { get; }

        //vertex1,vertex2, vertex3; vertex4 //- fields vertex1, vertex2, vertex3 of type Point
        public Rectangle() { }
        public Rectangle(Point a, Point c)

        {
            vertex1 = a;
            vertex3 = c;
            Point vertex2 = new Point(a.X, c.Y);
            Point vertex4 = new Point(c.X, a.Y);
        }

        public double Perimeter()
        {
            double a = vertex1.GetDistance(vertex1, vertex2);
            double b = vertex2.GetDistance(vertex2, vertex3);
            //double c = vertex3.GetDistance(vertex3, vertex4);
            //double d = vertex4.GetDistance(vertex4, vertex1);

            return 2 * (a + b);
        }
        public double Square()
        {
            double a = vertex1.GetDistance(vertex1, vertex2);
            double b = vertex2.GetDistance(vertex2, vertex3);
            //double c = vertex3.GetDistance(vertex3, vertex4);
            //double d = vertex4.GetDistance(vertex4, vertex1);

            return a * b;
        }

        public void Print()
        {
            Console.WriteLine($"Triangle has perimeter{Perimeter()} and square {Square()} ");
        }
    }
    public class Circle
    {
        public double radius;
        public const double PI = 3.14159265358979;
        public Circle()
        { }
        public Circle(double radius)
        {
            this.radius = radius;
        }
        public double GetArea()
        {
            double Sc = PI * (radius * radius);
            return Sc;
        }
        public double GetPerimeter()
        {
            double Pc = 2 * PI * radius;
            return Pc;
        }
        public Circle Input()
        {
            Circle cl = new Circle();
            Console.WriteLine("Enter radius of the Circle:");
            cl.radius = Convert.ToDouble(Console.ReadLine());
            return cl;
        }
    }

    public static class CircleSt
    {
        public const double PI = 3.14159265358979;
        public static double GetArea(double r)
        {
            double Sc = PI * (r * r);
            return Sc;
        }
        public static double GetPerimeter(double r)
        {
            double Pc = 2 * PI * r;
            return Pc;
        }
    }

    class ComplexNumber
    {
        private double m_real = 0.0;
        private double m_imag = 0.0;

        #region Конструкторы
        public ComplexNumber()
        {
        }

        public ComplexNumber(double re)
        {
            m_real = re;
        }

        public ComplexNumber(double re, double im)
        {
            m_real = re;
            m_imag = im;
        }

        public ComplexNumber(ComplexNumber x)
        {
            m_real = x.Real;
            m_imag = x.Imag;
        }
        #endregion

        public double Real
        {
            get { return m_real; }
            set { m_real = value; }
        }

        public double Imag
        {
            get { return m_imag; }
            set { m_imag = value; }
        }

        public double Abs
        {
            get { return Math.Sqrt(m_imag * m_imag + m_real * m_real); }
        }

        public double Arg
        {
            get { return Math.Atan(m_imag / m_real); }
        }

        /// <summary>
        /// Получить комплексно-сопряженное число
        /// </summary>
        public ComplexNumber GetConjugate()
        {
            return new ComplexNumber(m_real, -m_imag);
        }

        public override string ToString()
        {
            string res = "";

            if (m_real != 0.0)
            {
                res = m_real.ToString();
            }

            if (m_imag != 0.0)
            {
                if (m_imag > 0)
                {
                    res += "+";
                }

                res += m_imag.ToString() + "i";
            }

            return res;
        }

        #region overloaded Multiply operators
        public static ComplexNumber operator *(ComplexNumber c1, ComplexNumber c2)
        {
            return new ComplexNumber(c1.Real * c2.Real - c1.Imag * c2.Imag,
                c1.Real * c2.Imag + c1.Imag * c2.Real);
        }

        public static ComplexNumber operator *(ComplexNumber c1, double c2)
        {
            return new ComplexNumber(c1.Real * c2, c1.Imag * c2);
        }

        public static ComplexNumber operator *(double c1, ComplexNumber c2)
        {
            return new ComplexNumber(c1 * c2.Real, c1 * c2.Imag);
        }
        #endregion

        #region overloaded Division
        public static ComplexNumber operator /(ComplexNumber c1, ComplexNumber c2)
        {
            double Denominator = c2.Real * c2.Real + c2.Imag * c2.Imag;
            return new ComplexNumber((c1.Real * c2.Real + c1.Imag * c2.Imag) / Denominator,
                (c2.Real * c1.Imag - c2.Imag * c1.Real) / Denominator);
        }

        public static ComplexNumber operator /(ComplexNumber c1, double c2)
        {
            return new ComplexNumber(c1.Real / c2, c1.Imag / c2);
        }

        public static ComplexNumber operator /(double c1, ComplexNumber c2)
        {
            double Denominator = c2.Real * c2.Real + c2.Imag * c2.Imag;
            return new ComplexNumber((c1 * c2.Real) / Denominator, (-c2.Imag * c1) / Denominator);
        }
        #endregion
    }



    abstract class Figure : Idrowable

    {
        //private double x;
        //private double y;
        public double X { get; private set; }
        public double Y { get; private set; }

        public Figure(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }

        public virtual void Drow()
        {
            Console.WriteLine("This is Figure class");
        }
    }
    interface IDrowable
    {
        void Drow();

        void DrawAll(params IDrawable[] array)
        {
            IDrowable[1] = new Figure(x, y);
            IDrowable[2] = new Square(x, y);
            IDrowable[3] = new RectangleF(x, y);

            foreach (var i in IDrowable)
            {
                i.Drow(i);
            }
        }
    }

    class Square : Figure, Idrowable

    {
        public Square(double x, double y) : base(x, y)
        {
        }

        public override void Drow()
        {
            Console.WriteLine("This is Square class");
        }
    }
    class RectangleF : Figure, IDrowable
    {
        public RectangleF(double x, double y) : base(x, y)
        {

        }
        public override void Drow()
        {
            Console.WriteLine("This is RectangleF class");
        }

    }

    class Program
    {
        static void Main(string[] args)

        {
            Rectangle rctgl = new Rectangle();
            rctgl.Perimeter();
            rctgl.Square();
            rctgl.Print();

            Circle crcl = new Circle();
            crcl.Input();
            crcl.GetArea();
            crcl.GetPerimeter();


        }
    }
}